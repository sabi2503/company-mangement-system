from django.db import models

# Create your models here.
class Employee(models.Model):
    name = models.CharField(max_length=20)
    email=models.EmailField(max_length=23)
    address = models.CharField(max_length=44)
    jobrole=models.CharField(max_length=88)

    def __str__(self):
        return self.name